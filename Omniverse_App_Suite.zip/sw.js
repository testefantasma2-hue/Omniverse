const CACHE_NAME = 'omniverse-v2';
const ASSETS = ['./', './index.html', './ficha.html', './dossie.html', './regras.html', './bestiario.html', './manifest.json', './icon.svg'];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS)));
  self.skipWaiting();
});
self.addEventListener('fetch', e => {
  e.respondWith(caches.match(e.request).then(res => res || fetch(e.request)));
});