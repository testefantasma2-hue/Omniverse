# 🌌 Omniverse RPG Companion

Aplicativo unificado contendo **Ficha de Personagem**, **Dossiê de Entidades (P.A.C.E.)**, **Livro de Regras v2.0** e **Bestiário Tático**.

## 🚀 Como usar no GitHub (2 Formas)

### Opção A: Web App / PWA Instalável (GitHub Pages - Instantâneo)
1. Suba todos os arquivos deste `.zip` para um repositório no seu GitHub.
2. Vá em **Settings** > **Pages** (no menu lateral do GitHub).
3. Em **Branch**, selecione `main` e clique em **Save**.
4. Em 1 minuto, seu app estará online! Abra o link no seu Tablet ou Celular e clique em **"Adicionar à Tela Inicial / Instalar Aplicativo"**. Ele funcionará como um app nativo e 100% offline.

### Opção B: Baixar o arquivo `.APK` para Android (Automático via GitHub Actions)
1. Assim que você subir os arquivos no GitHub, clique na aba **Actions** no topo do seu repositório.
2. O fluxo **"Gerar Android APK e Publicar"** vai rodar sozinho (ou você pode clicar em *Run workflow*).
3. Quando ficar verde (cerca de 2 minutos), clique nele e baixe o arquivo **`Omniverse-Android-APK`** na seção *Artifacts*!