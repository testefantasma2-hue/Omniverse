/* Armazenamento local dos personagens.
   Por enquanto usa localStorage (simples e funciona em qualquer WebView).
   Na Fase 3 isso deve migrar pra um plugin de SQLite do Capacitor, pra suportar
   mais dados (campanhas, bestiário enfrentado, etc.) sem o limite de ~5-10MB do localStorage. */

const PERSONAGENS_KEY = 'omniverse_personagens_v1';

function listarPersonagens(){
  try{ return JSON.parse(localStorage.getItem(PERSONAGENS_KEY)) || {}; }
  catch(e){ return {}; }
}
function salvarPersonagem(id, dados){
  const todos = listarPersonagens();
  todos[id] = dados;
  try{
    localStorage.setItem(PERSONAGENS_KEY, JSON.stringify(todos));
    return true;
  }catch(e){
    console.error('Falha ao salvar personagem:', e);
    return false;
  }
}
function excluirPersonagem(id){
  const todos = listarPersonagens();
  delete todos[id];
  localStorage.setItem(PERSONAGENS_KEY, JSON.stringify(todos));
}
function gerarIdPersonagem(){
  return 'pj_' + Date.now() + '_' + Math.random().toString(36).slice(2,7);
}
