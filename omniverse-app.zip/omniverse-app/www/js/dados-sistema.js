/* Dados do Sistema Omniverse v2.0 — extraídos do Livro de Regras */

const ATRIBUTOS = [
  { id: 'for', nome: 'Força', sigla: 'FOR', desc: 'Potência muscular bruta, carga e impacto físico.' },
  { id: 'agi', nome: 'Agilidade', sigla: 'AGI', desc: 'Velocidade de reação, furtividade e esquiva.' },
  { id: 'res', nome: 'Vigor / Resistência', sigla: 'RES', desc: 'Integridade biológica, base de PV e Estamina.' },
  { id: 'int', nome: 'Intelecto', sigla: 'INT', desc: 'Raciocínio analítico, ciência e estratégia.' },
  { id: 'ins', nome: 'Instinto', sigla: 'INS', desc: 'Sentidos aguçados, iniciativa e pontaria instintiva.' },
  { id: 'esp', nome: 'Espírito', sigla: 'ESP', desc: 'Conjuração e base da Sanidade.' },
  { id: 'car', nome: 'Carisma / Presença', sigla: 'CAR', desc: 'Liderança, manipulação e imposição social.' },
  { id: 'esf', nome: 'Esforço', sigla: 'ESF', desc: 'Reserva de superação pra cobrir falhas em momentos críticos.' }
];
const PONTOS_ATRIBUTOS_NV1 = 300;
const LIMITE_ATRIBUTO_NV1 = 60;

const PERICIAS = {
  'Conhecimento & Investigação': {
    atributo: 'INT/ESP',
    lista: ['Arqueologia','Antropologia','História','Ocultismo','Ciências','Medicina','Primeiros Socorros',
      'Psicologia','Filosofia','Religião','Criptografia','Pesquisa','Cibernética','Tecnologia','Educação',
      'Investigação','Estratégia','Teologia','Análise','Linguística','Conjuração','Conhecimento Popular',
      'Biblioteconomia','Avaliação','Direito','Línguas']
  },
  'Sociais & Interpessoais': {
    atributo: 'CAR/INS',
    lista: ['Persuasão','Intimidação','Sedução','Enganação','Disfarce','Carisma','Lábia','Charme',
      'Diplomacia','Atuação','Leitura Corporal']
  },
  'Percepção & Sobrevivência': {
    atributo: 'INS/RES',
    lista: ['Percepção','Rastrear','Detectar Armadilhas','Intuição','Sorte','Sobrevivência','Navegar',
      'Resistência','Vontade','Iniciativa']
  },
  'Físicas, Combate & Técnicas': {
    atributo: 'FOR/AGI',
    lista: ['Atletismo','Escalar','Saltar','Nadar','Esquiva','Acrobacia','Furtividade','Luta','Pontaria',
      'Pilotar','Montar','Operar Máquinas','Mecânica','Elétrica','Crime','Prestidigitação','Engenharia',
      'Consertar','Construir','Operar Rádio','Usar Ferramentas']
  }
};
const PONTOS_PERICIAS_NV1 = 800;
const LIMITE_PERICIA_NV1 = 60;

const ARQUETIPOS = {
  bruto: {
    nome: 'Bruto',
    desc: 'Guerreiros de linha de frente que moldaram a própria carne pra suportar impacto e revidar com força devastadora.',
    pv: (atrib) => 20 + (atrib.res * 1.5),
    est: (atrib) => 15 + (atrib.res * 1.5),
    san: (atrib) => 20 + atrib.esp
  },
  habil: {
    nome: 'Hábil',
    desc: 'Especialistas em precisão, mobilidade tática e leitura cirúrgica do campo de batalha.',
    pv: (atrib) => 15 + (atrib.res * 1.0),
    est: (atrib) => 20 + (atrib.res * 1.2) + (atrib.agi / 2),
    san: (atrib) => 30 + (atrib.esp * 1.2)
  },
  gnostico: {
    nome: 'Gnóstico',
    desc: 'Estudiosos do oculto e canalizadores que compreenderam as leis metafísicas da realidade. Corpo frágil, mente poderosa.',
    pv: (atrib) => 10 + (atrib.res * 0.8),
    est: (atrib) => 15 + (atrib.esp * 1.2) + (atrib.res / 2),
    san: (atrib) => 45 + (atrib.esp * 1.5)
  }
};

/* Hélice da Ascensão — equivalência entre Rank (jogador) e Categoria (bestiário) */
const HELICE_ASCENSAO = [
  { rank:'F', categoria:'I',   np:'1 – 25',    gs:'+0', ref:'Humano comum a Operador iniciante' },
  { rank:'E', categoria:'II',  np:'26 – 75',   gs:'+1', ref:'Atleta lendário / Predador urbano' },
  { rank:'D', categoria:'III', np:'76 – 150',  gs:'+2', ref:'Super-humano / Anomalia severa' },
  { rank:'C', categoria:'IV',  np:'151 – 300', gs:'+3', ref:'Unidade de destruição tática' },
  { rank:'B', categoria:'V',   np:'301 – 500', gs:'+4', ref:'Ameaça Cataclísmica Regional' },
  { rank:'A', categoria:'VI',  np:'501 – 750', gs:'+5', ref:'Nível Desastre / Calamidade' },
  { rank:'S', categoria:'VII', np:'751 – 1000',gs:'+6', ref:'Extinção / Entidade Transcendente' }
];
