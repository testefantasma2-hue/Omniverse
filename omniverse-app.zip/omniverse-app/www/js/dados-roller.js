/* ---------- Motor de dados: aleatoriedade correta, sem viés de módulo ----------
   Math.random() + "% faces" tende a favorecer levemente os números baixos quando
   o intervalo de bytes não é múltiplo exato do número de faces. A técnica correta
   é rejection sampling: gera bytes aleatórios de verdade (crypto.getRandomValues)
   e descarta os valores que cairiam fora de uma faixa que seja múltiplo exato das
   faces, ao invés de só aplicar módulo em cima de qualquer valor. */

function randomIntSemVies(max){
  if(max <= 0) return 0;
  const bytesNecessarios = Math.ceil(Math.log2(max) / 8) || 1;
  const totalPossivel = 256 ** bytesNecessarios;
  const limiteValido = Math.floor(totalPossivel / max) * max;
  let valor;
  do{
    const bytes = new Uint8Array(bytesNecessarios);
    crypto.getRandomValues(bytes);
    valor = bytes.reduce((acc, byte, i) => acc + byte * (256 ** i), 0);
  } while(valor >= limiteValido);
  return valor % max;
}
function rolarDado(faces){
  return randomIntSemVies(faces) + 1;
}

const FACES_DISPONIVEIS = [2, 4, 6, 10, 12, 20, 100];

/* ---------- Rolagem de uma combinação (grupo de dados + modificador) ---------- */
function rolarCombinacao(grupos, modificador){
  modificador = modificador || 0;
  let total = modificador;
  const detalhes = [];
  grupos.forEach(g=>{
    const resultados = [];
    for(let i=0;i<g.qtd;i++){
      const r = rolarDado(g.tipo);
      resultados.push(r);
      total += r;
    }
    detalhes.push({ tipo:g.tipo, qtd:g.qtd, resultados });
  });
  return { total, detalhes, modificador };
}

function formatarNotacao(grupos, modificador){
  let texto = grupos.map(g=>`${g.qtd}d${g.tipo}`).join(' + ');
  if(modificador > 0) texto += ` + ${modificador}`;
  if(modificador < 0) texto += ` - ${Math.abs(modificador)}`;
  return texto || '—';
}
function formatarDetalhe(resultado){
  const partes = resultado.detalhes.map(d=>`${d.qtd}d${d.tipo} (${d.resultados.join(', ')})`);
  let texto = partes.join(' + ');
  if(resultado.modificador > 0){
    texto = texto ? `${texto} + ${resultado.modificador}` : `${resultado.modificador}`;
  } else if(resultado.modificador < 0){
    texto = texto ? `${texto} - ${Math.abs(resultado.modificador)}` : `${resultado.modificador}`;
  }
  return texto || '0';
}

/* ---------- Histórico de rolagens (persistido, com teto de tamanho) ---------- */
const HISTORICO_KEY = 'omniverse_historico_dados_v1';
const HISTORICO_MAX = 50;

function lerHistorico(){
  try{ return JSON.parse(localStorage.getItem(HISTORICO_KEY)) || []; }
  catch(e){ return []; }
}
function registrarHistorico(nome, resultado){
  const historico = lerHistorico();
  historico.unshift({
    nome: nome,
    notacao: formatarNotacao(resultado.detalhes.map(d=>({tipo:d.tipo, qtd:d.qtd})), resultado.modificador),
    detalhe: formatarDetalhe(resultado),
    total: resultado.total,
    quando: Date.now()
  });
  if(historico.length > HISTORICO_MAX) historico.length = HISTORICO_MAX;
  try{ localStorage.setItem(HISTORICO_KEY, JSON.stringify(historico)); }
  catch(e){ console.error('Falha ao salvar histórico de dados:', e); }
}
function limparHistorico(){
  localStorage.removeItem(HISTORICO_KEY);
}

/* ---------- Presets: Arsenal e Magia ---------- */
const PRESETS_KEY = 'omniverse_presets_dados_v1';

function listarPresets(){
  try{ return JSON.parse(localStorage.getItem(PRESETS_KEY)) || {}; }
  catch(e){ return {}; }
}
function salvarPreset(id, preset){
  const todos = listarPresets();
  todos[id] = preset;
  try{ localStorage.setItem(PRESETS_KEY, JSON.stringify(todos)); return true; }
  catch(e){ console.error('Falha ao salvar preset:', e); return false; }
}
function excluirPreset(id){
  const todos = listarPresets();
  delete todos[id];
  localStorage.setItem(PRESETS_KEY, JSON.stringify(todos));
}
function gerarIdPreset(){
  return 'preset_' + Date.now() + '_' + Math.random().toString(36).slice(2,7);
}
