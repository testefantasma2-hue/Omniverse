/* ================= Navegação principal (abas inferiores) ================= */
function mostrarView(nome){
  document.querySelectorAll('.nav-btn').forEach(b=> b.classList.toggle('active', b.dataset.view === nome));
  document.querySelectorAll('.view').forEach(v=> v.classList.remove('active'));
  document.getElementById('view-'+nome).classList.add('active');
  document.getElementById('header-title').textContent = { personagens:'Personagens', dados:'Dados', campanha:'Campanha' }[nome];
  if(nome === 'personagens') renderListaPersonagens();
  if(nome === 'dados') renderRolagemRapida();
}

/* ================= Aba Dados: sub-navegação ================= */
function mostrarSubAbaDados(nome){
  document.querySelectorAll('.sub-tab-btn').forEach(b=> b.classList.toggle('active', b.dataset.subtab === nome));
  document.querySelectorAll('.sub-view').forEach(v=> v.classList.remove('active'));
  document.getElementById('subview-'+nome).classList.add('active');
  if(nome === 'arsenal') renderListaPresets();
  if(nome === 'historico') renderHistorico();
}

/* ---------- Rolagem Rápida ---------- */
function renderRolagemRapida(){
  const container = document.getElementById('rolagem-rapida-tipos');
  if(!container) return;
  container.innerHTML = FACES_DISPONIVEIS.map(f=>`
    <div class="dado-tipo-row">
      <span class="dado-tipo-label">d${f}</span>
      <div class="stepper small">
        <button type="button" class="stepper-btn" data-rapido-tipo="${f}" data-delta="-1">−</button>
        <input type="number" class="qtd-dado-rapido" id="qtd-d${f}" value="0" min="0">
        <button type="button" class="stepper-btn" data-rapido-tipo="${f}" data-delta="1">+</button>
      </div>
    </div>`).join('');
}
function executarRolagemRapida(){
  const grupos = FACES_DISPONIVEIS
    .map(f => ({ tipo: f, qtd: parseInt(document.getElementById('qtd-d'+f).value) || 0 }))
    .filter(g => g.qtd > 0);
  const modificador = parseInt(document.getElementById('modificador-rapido').value) || 0;
  if(grupos.length === 0 && modificador === 0){
    mostrarAvisoDados('Escolha ao menos um dado pra rolar.');
    return;
  }
  const resultado = rolarCombinacao(grupos, modificador);
  mostrarResultadoRolagem(resultado, 'Rolagem Rápida');
  registrarHistorico('Rolagem Rápida', resultado);
}
function mostrarResultadoRolagem(resultado, nome){
  const el = document.getElementById('resultado-rolagem');
  el.innerHTML = `
    <div class="resultado-nome">${nome}</div>
    <div class="resultado-total">${resultado.total}</div>
    <div class="resultado-detalhe">${formatarDetalhe(resultado)}</div>`;
  el.classList.remove('animar');
  void el.offsetWidth;
  el.classList.add('animar');
}
function mostrarAvisoDados(msg){
  const el = document.getElementById('resultado-rolagem');
  el.innerHTML = `<div class="resultado-aviso">${msg}</div>`;
}

/* ---------- Arsenal e Magia: lista de presets ---------- */
function renderListaPresets(){
  const container = document.getElementById('lista-presets');
  const presets = listarPresets();
  const entradas = Object.entries(presets);
  if(entradas.length === 0){ container.innerHTML = '<p class="vazio">Nenhum preset salvo ainda.</p>'; return; }
  container.innerHTML = entradas.map(([id, p])=>`
    <div class="card-preset">
      <div class="card-preset-info">
        <strong>${p.nome}</strong>
        <small>${formatarNotacao(p.grupos, p.modificador)}</small>
        ${p.descricao ? `<p class="preset-descricao">${p.descricao}</p>` : ''}
      </div>
      <div class="card-preset-acoes">
        <button class="btn-icone" data-rolar-preset="${id}" title="Rolar">🎲</button>
        <button class="btn-icone" data-editar-preset="${id}" title="Editar">✎</button>
        <button class="btn-icone perigo" data-excluir-preset="${id}" title="Excluir">×</button>
      </div>
    </div>`).join('');
}

/* ---------- Arsenal e Magia: formulário de criação/edição ---------- */
let presetFormState = null;

function abrirFormularioPreset(id){
  const presets = listarPresets();
  const existente = id ? presets[id] : null;
  presetFormState = existente
    ? { id, nome: existente.nome, descricao: existente.descricao, grupos: existente.grupos.map(g=>({...g})), modificador: existente.modificador }
    : { id: null, nome: '', descricao: '', grupos: [{tipo:6, qtd:1}], modificador: 0 };
  renderFormularioPreset();
  document.getElementById('presets-lista-view').classList.remove('active');
  document.getElementById('presets-form-view').classList.add('active');
}
function fecharFormularioPreset(){
  document.getElementById('presets-form-view').classList.remove('active');
  document.getElementById('presets-lista-view').classList.add('active');
  renderListaPresets();
}
function renderFormularioPreset(){
  document.getElementById('presets-form-conteudo').innerHTML = `
    <label>Nome<input type="text" id="preset-nome" value="${presetFormState.nome}" placeholder="Espada Longa, Bola de Fogo..."></label>
    <label>Descrição<textarea id="preset-descricao" placeholder="Efeito, tipo de dano, alcance, custo...">${presetFormState.descricao}</textarea></label>
    <span class="label-solto">Combinação de Dados</span>
    <div id="preset-grupos-lista">${renderGruposPreset()}</div>
    <button type="button" class="btn-secundario" data-acao="add-grupo-preset">+ adicionar dado</button>
    <label>Modificador Fixo<input type="number" id="preset-modificador" value="${presetFormState.modificador}"></label>
  `;
}
function renderGruposPreset(){
  return presetFormState.grupos.map((g,i)=>`
    <div class="preset-grupo-row">
      <select class="preset-grupo-tipo" data-idx="${i}">
        ${FACES_DISPONIVEIS.map(f=>`<option value="${f}" ${f===g.tipo?'selected':''}>d${f}</option>`).join('')}
      </select>
      <input type="number" class="preset-grupo-qtd" data-idx="${i}" value="${g.qtd}" min="1">
      <button type="button" class="btn-icone perigo" data-remover-grupo="${i}">×</button>
    </div>`).join('');
}
function salvarFormularioPreset(){
  presetFormState.nome = document.getElementById('preset-nome').value.trim() || 'Sem nome';
  presetFormState.descricao = document.getElementById('preset-descricao').value;
  presetFormState.modificador = parseInt(document.getElementById('preset-modificador').value) || 0;
  if(presetFormState.grupos.length === 0){ alert('Adicione ao menos um dado à combinação.'); return; }
  const id = presetFormState.id || gerarIdPreset();
  salvarPreset(id, { nome: presetFormState.nome, descricao: presetFormState.descricao, grupos: presetFormState.grupos, modificador: presetFormState.modificador });
  fecharFormularioPreset();
}

/* ---------- Histórico ---------- */
function renderHistorico(){
  const container = document.getElementById('lista-historico');
  const historico = lerHistorico();
  if(historico.length === 0){ container.innerHTML = '<p class="vazio">Nenhuma rolagem registrada ainda.</p>'; return; }
  container.innerHTML = historico.map(h=>{
    const hora = new Date(h.quando).toLocaleTimeString('pt-BR', {hour:'2-digit', minute:'2-digit'});
    return `
    <div class="card-historico">
      <div class="historico-topo"><strong>${h.nome}</strong><span class="historico-hora">${hora}</span></div>
      <div class="historico-detalhe">${h.detalhe}</div>
      <div class="historico-total">= ${h.total}</div>
    </div>`;
  }).join('');
}

/* ================= Delegação de eventos geral ================= */
document.addEventListener('click', function(e){
  // Navegação
  const navBtn = e.target.closest('.nav-btn');
  if(navBtn) mostrarView(navBtn.dataset.view);
  const subTabBtn = e.target.closest('.sub-tab-btn');
  if(subTabBtn) mostrarSubAbaDados(subTabBtn.dataset.subtab);

  // Personagens
  if(e.target.id === 'btn-novo-personagem') abrirFormularioPersonagem(null);
  if(e.target.id === 'btn-salvar-personagem') salvarFormularioAtual();
  if(e.target.id === 'btn-cancelar-personagem') fecharFormularioPersonagem();

  // Rolagem rápida
  const stepperRapido = e.target.closest('.stepper-btn');
  if(stepperRapido && stepperRapido.dataset.rapidoTipo){
    const input = document.getElementById('qtd-d'+stepperRapido.dataset.rapidoTipo);
    const delta = parseInt(stepperRapido.dataset.delta);
    input.value = Math.max(0, (parseInt(input.value)||0) + delta);
  }
  if(e.target.id === 'btn-rolar-rapido') executarRolagemRapida();

  // Presets: ações na lista
  const rolarBtn = e.target.closest('[data-rolar-preset]');
  if(rolarBtn){
    const p = listarPresets()[rolarBtn.dataset.rolarPreset];
    if(p){
      const resultado = rolarCombinacao(p.grupos, p.modificador);
      mostrarResultadoRolagem(resultado, p.nome);
      registrarHistorico(p.nome, resultado);
    }
  }
  const editarPresetBtn = e.target.closest('[data-editar-preset]');
  if(editarPresetBtn) abrirFormularioPreset(editarPresetBtn.dataset.editarPreset);
  const excluirPresetBtn = e.target.closest('[data-excluir-preset]');
  if(excluirPresetBtn && confirm('Excluir este preset?')){ excluirPreset(excluirPresetBtn.dataset.excluirPreset); renderListaPresets(); }

  // Presets: formulário
  if(e.target.id === 'btn-novo-preset') abrirFormularioPreset(null);
  if(e.target.id === 'btn-salvar-preset') salvarFormularioPreset();
  if(e.target.id === 'btn-cancelar-preset') fecharFormularioPreset();
  if(e.target.dataset.acao === 'add-grupo-preset'){
    presetFormState.grupos.push({tipo:6, qtd:1});
    document.getElementById('preset-grupos-lista').innerHTML = renderGruposPreset();
  }
  const removerGrupoBtn = e.target.closest('[data-remover-grupo]');
  if(removerGrupoBtn){
    presetFormState.grupos.splice(parseInt(removerGrupoBtn.dataset.removerGrupo), 1);
    document.getElementById('preset-grupos-lista').innerHTML = renderGruposPreset();
  }

  // Histórico
  if(e.target.id === 'btn-limpar-historico' && confirm('Limpar todo o histórico de rolagens?')){
    limparHistorico();
    renderHistorico();
  }
});
document.addEventListener('change', function(e){
  if(e.target.classList.contains('preset-grupo-tipo')){
    presetFormState.grupos[parseInt(e.target.dataset.idx)].tipo = parseInt(e.target.value);
  }
});
document.addEventListener('input', function(e){
  if(e.target.classList.contains('preset-grupo-qtd')){
    presetFormState.grupos[parseInt(e.target.dataset.idx)].qtd = Math.max(1, parseInt(e.target.value) || 1);
  }
});

/* ================= Inicialização ================= */
mostrarView('personagens');
