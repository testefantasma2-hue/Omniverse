/* ---------- Estado do formulário em edição ---------- */
let formState = null;

function slugify(str){
  return str.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-');
}
function novoFormState(){
  return { id: null, atributos: {}, pericias: {}, arquetipo: null };
}

/* ================= LISTA DE PERSONAGENS ================= */
function renderListaPersonagens(){
  const container = document.getElementById('lista-personagens');
  const personagens = listarPersonagens();
  const entradas = Object.entries(personagens).sort((a,b)=> (b[1].atualizadoEm||0) - (a[1].atualizadoEm||0));
  if(entradas.length === 0){
    container.innerHTML = '<p class="vazio">Nenhum personagem criado ainda.</p>';
    return;
  }
  container.innerHTML = entradas.map(([id, pj])=>{
    const arq = ARQUETIPOS[pj.arquetipo];
    const pv = arq ? Math.round(arq.pv({res: pj.atributos.res||0})) : '?';
    const san = arq ? Math.round(arq.san({esp: pj.atributos.esp||0})) : '?';
    return `
    <div class="card-personagem" data-id="${id}">
      <div class="card-personagem-info">
        <strong>${pj.nome || 'Sem nome'}</strong>
        <small>${arq ? arq.nome : 'Sem arquétipo'} · PV ${pv} · SAN ${san}</small>
      </div>
      <div class="card-personagem-acoes">
        <button class="btn-icone" data-acao="editar" data-id="${id}">✎</button>
        <button class="btn-icone perigo" data-acao="excluir" data-id="${id}">×</button>
      </div>
    </div>`;
  }).join('');
}

document.addEventListener('click', function(e){
  const btn = e.target.closest('[data-acao]');
  if(!btn) return;
  const id = btn.dataset.id;
  if(btn.dataset.acao === 'editar') abrirFormularioPersonagem(id);
  if(btn.dataset.acao === 'excluir'){
    if(confirm('Excluir este personagem permanentemente?')){
      excluirPersonagem(id);
      renderListaPersonagens();
    }
  }
});

/* ================= FORMULÁRIO DE CRIAÇÃO ================= */
function abrirFormularioPersonagem(id){
  const personagens = listarPersonagens();
  const existente = id ? personagens[id] : null;
  formState = novoFormState();
  if(existente){
    formState.id = id;
    formState.atributos = {...existente.atributos};
    formState.pericias = {...existente.pericias};
    formState.arquetipo = existente.arquetipo;
  }
  document.getElementById('lista-personagens-view').classList.remove('active');
  document.getElementById('form-personagem-view').classList.add('active');
  renderFormularioPersonagem(existente);
}

function fecharFormularioPersonagem(){
  document.getElementById('form-personagem-view').classList.remove('active');
  document.getElementById('lista-personagens-view').classList.add('active');
  renderListaPersonagens();
}

function renderFormularioPersonagem(existente){
  const e = existente || {};
  const container = document.getElementById('form-personagem-conteudo');
  container.innerHTML = `
    <section class="form-secao">
      <h2>Identidade</h2>
      <label>Nome<input type="text" id="campo-nome" value="${e.nome || ''}"></label>
      <div class="row3">
        <label>Altura<input type="text" id="campo-altura" value="${e.altura || ''}" placeholder="1,80m"></label>
        <label>Peso<input type="text" id="campo-peso" value="${e.peso || ''}" placeholder="75kg"></label>
        <label>Idade<input type="text" id="campo-idade" value="${e.idade || ''}" placeholder="28"></label>
      </div>
      <label>Características Físicas<textarea id="campo-caracteristicas" placeholder="Marcas, trejeitos, vestimenta...">${e.caracteristicas || ''}</textarea></label>
    </section>

    <section class="form-secao">
      <h2>Atributos</h2>
      <div class="pontos-resumo" id="resumo-atributos"></div>
      <div id="lista-atributos">${renderAtributosForm(formState.atributos)}</div>
    </section>

    <section class="form-secao">
      <h2>Arquétipo</h2>
      <div class="arquetipos-grid" id="lista-arquetipos">${renderArquetipoForm(formState.arquetipo, formState.atributos)}</div>
    </section>

    <section class="form-secao">
      <h2>Perícias</h2>
      <div class="pontos-resumo" id="resumo-pericias"></div>
      <div id="lista-pericias">${renderPericiasForm(formState.pericias)}</div>
    </section>

    <section class="form-secao">
      <h2>História</h2>
      <textarea id="campo-historia" class="textarea-grande" placeholder="Origem, motivações, segredos...">${e.historia || ''}</textarea>
    </section>
  `;
  atualizarResumoAtributos();
  atualizarResumoPericias();
}

/* ---------- Atributos: steppers + resumo de pontos ---------- */
function renderAtributosForm(valores){
  return ATRIBUTOS.map(a => `
    <div class="attr-row">
      <span class="attr-nome">${a.nome} <small>${a.sigla}</small></span>
      <div class="stepper">
        <button type="button" class="stepper-btn" data-attr="${a.id}" data-delta="-1">−</button>
        <input type="number" class="attr-valor" id="attr-${a.id}" data-attr="${a.id}" value="${valores[a.id]||0}" min="0" max="${LIMITE_ATRIBUTO_NV1}">
        <button type="button" class="stepper-btn" data-attr="${a.id}" data-delta="1">+</button>
      </div>
    </div>`).join('');
}
function atualizarResumoAtributos(){
  const total = ATRIBUTOS.reduce((s,a)=> s + (parseInt(formState.atributos[a.id])||0), 0);
  const restante = PONTOS_ATRIBUTOS_NV1 - total;
  const el = document.getElementById('resumo-atributos');
  el.textContent = `${restante} pontos restantes (de ${PONTOS_ATRIBUTOS_NV1})`;
  el.classList.toggle('negativo', restante < 0);
}
document.addEventListener('click', function(e){
  const btn = e.target.closest('.stepper-btn');
  if(!btn || !formState) return;
  const delta = parseInt(btn.dataset.delta);
  if(btn.dataset.attr){
    const input = document.getElementById('attr-'+btn.dataset.attr);
    const novo = Math.max(0, Math.min(LIMITE_ATRIBUTO_NV1, (parseInt(input.value)||0) + delta));
    input.value = novo;
    input.dispatchEvent(new Event('input', {bubbles:true}));
  }
  if(btn.dataset.pericia){
    const input = document.getElementById('per-'+btn.dataset.pericia);
    const novo = Math.max(0, Math.min(LIMITE_PERICIA_NV1, (parseInt(input.value)||0) + delta));
    input.value = novo;
    input.dispatchEvent(new Event('input', {bubbles:true}));
  }
});
document.addEventListener('input', function(e){
  if(!formState) return;
  if(e.target.classList.contains('attr-valor')){
    formState.atributos[e.target.dataset.attr] = parseInt(e.target.value)||0;
    atualizarResumoAtributos();
    document.getElementById('lista-arquetipos').innerHTML = renderArquetipoForm(formState.arquetipo, formState.atributos);
  }
  if(e.target.classList.contains('pericia-valor')){
    formState.pericias[e.target.dataset.pericia] = parseInt(e.target.value)||0;
    atualizarResumoPericias();
  }
});

/* ---------- Perícias: categorias colapsáveis + steppers + resumo ---------- */
function renderPericiasForm(valores){
  return Object.entries(PERICIAS).map(([categoria, info])=>`
    <details class="pericia-categoria">
      <summary>${categoria} <small>(${info.atributo})</small></summary>
      <div class="pericia-lista">
        ${info.lista.map(p=>{
          const key = slugify(p);
          return `
          <div class="pericia-row">
            <span>${p}</span>
            <div class="stepper small">
              <button type="button" class="stepper-btn" data-pericia="${key}" data-delta="-5">−</button>
              <input type="number" class="pericia-valor" id="per-${key}" data-pericia="${key}" value="${valores[key]||0}" min="0" max="${LIMITE_PERICIA_NV1}">
              <button type="button" class="stepper-btn" data-pericia="${key}" data-delta="5">+</button>
            </div>
          </div>`;
        }).join('')}
      </div>
    </details>`).join('');
}
function atualizarResumoPericias(){
  let total = 0;
  Object.values(PERICIAS).forEach(info=> info.lista.forEach(p=>{ total += parseInt(formState.pericias[slugify(p)])||0; }));
  const restante = PONTOS_PERICIAS_NV1 - total;
  const el = document.getElementById('resumo-pericias');
  el.textContent = `${restante} pontos restantes (de ${PONTOS_PERICIAS_NV1})`;
  el.classList.toggle('negativo', restante < 0);
}

/* ---------- Arquétipo: cards selecionáveis com PV/EST/SAN ao vivo ---------- */
function renderArquetipoForm(selecionado, atributosAtuais){
  return Object.entries(ARQUETIPOS).map(([id, arq])=>{
    const atrib = { res: parseInt(atributosAtuais.res)||0, esp: parseInt(atributosAtuais.esp)||0, agi: parseInt(atributosAtuais.agi)||0 };
    const pv = Math.round(arq.pv(atrib));
    const est = Math.round(arq.est(atrib));
    const san = Math.round(arq.san(atrib));
    return `
    <div class="arquetipo-card${selecionado===id?' selecionado':''}" data-arquetipo="${id}">
      <h3>${arq.nome}</h3>
      <p>${arq.desc}</p>
      <div class="arquetipo-stats"><span>PV <b>${pv}</b></span><span>EST <b>${est}</b></span><span>SAN <b>${san}</b></span></div>
    </div>`;
  }).join('');
}
document.addEventListener('click', function(e){
  const card = e.target.closest('.arquetipo-card');
  if(!card || !formState) return;
  formState.arquetipo = card.dataset.arquetipo;
  document.getElementById('lista-arquetipos').innerHTML = renderArquetipoForm(formState.arquetipo, formState.atributos);
});

/* ---------- Salvar ---------- */
function salvarFormularioAtual(){
  if(!formState.arquetipo){
    alert('Escolha um Arquétipo antes de salvar.');
    return;
  }
  const totalAtrib = ATRIBUTOS.reduce((s,a)=> s + (parseInt(formState.atributos[a.id])||0), 0);
  let totalPer = 0;
  Object.values(PERICIAS).forEach(info=> info.lista.forEach(p=>{ totalPer += parseInt(formState.pericias[slugify(p)])||0; }));
  if(totalAtrib > PONTOS_ATRIBUTOS_NV1 || totalPer > PONTOS_PERICIAS_NV1){
    if(!confirm('Os pontos de atributos ou perícias ultrapassam o limite. Salvar mesmo assim?')) return;
  }
  const dados = {
    nome: document.getElementById('campo-nome').value.trim() || 'Sem nome',
    altura: document.getElementById('campo-altura').value,
    peso: document.getElementById('campo-peso').value,
    idade: document.getElementById('campo-idade').value,
    caracteristicas: document.getElementById('campo-caracteristicas').value,
    atributos: {...formState.atributos},
    arquetipo: formState.arquetipo,
    pericias: {...formState.pericias},
    historia: document.getElementById('campo-historia').value,
    atualizadoEm: Date.now()
  };
  const id = formState.id || gerarIdPersonagem();
  salvarPersonagem(id, dados);
  fecharFormularioPersonagem();
}
