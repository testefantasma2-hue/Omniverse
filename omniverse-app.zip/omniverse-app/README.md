# Omniverse RPG — App

Esse é o começo do app do Sistema Omniverse: criação de personagem (Fase 2 em andamento)
e modo campanha (ainda não construído — Fase 4 do roteiro).

## Como colocar isso no ar (passo a passo, sem usar linha de comando)

### 1. Criar o repositório no GitHub
1. Entre em [github.com](https://github.com) e faça login (ou crie uma conta, é grátis).
2. Clique no `+` no canto superior direito → **New repository**.
3. Nome sugerido: `omniverse-app`. Deixe como **Public** ou **Private**, tanto faz.
4. **NÃO** marque "Add a README file" (o nosso já vem pronto).
5. Clique em **Create repository**.

### 2. Instalar o GitHub Desktop (interface visual, sem comandos)
1. Baixe em [desktop.github.com](https://desktop.github.com) e instale.
2. Abra o GitHub Desktop e faça login com a mesma conta do GitHub.
3. Clique em **File → Clone Repository**, escolha o `omniverse-app` que você acabou de
   criar, e selecione uma pasta no seu computador pra salvar.

### 3. Copiar os arquivos pra dentro da pasta clonada
1. Pegue **todos os arquivos e pastas** que eu te entreguei (incluindo a pasta `.github`,
   que pode estar escondida — no Windows/Mac você pode precisar ativar "mostrar arquivos
   ocultos").
2. Cole tudo dentro da pasta que o GitHub Desktop criou ao clonar (a mesma pasta que você
   escolheu no passo 2.3).

### 4. Subir pro GitHub (commit + push)
1. Volte pro GitHub Desktop — ele vai mostrar todos os arquivos novos detectados.
2. No campo de mensagem (embaixo à esquerda), escreva algo como "primeira versão do app".
3. Clique em **Commit to main**.
4. Clique em **Push origin** (botão azul no topo).

### 5. Baixar o APK compilado
1. No site do GitHub, abra seu repositório e clique na aba **Actions** (no topo).
2. Você vai ver "Build Android APK" rodando (uma bolinha amarela girando). Espera uns 3-5
   minutos até virar um ✓ verde.
3. Clique nesse workflow → desça até **Artifacts** → baixe `omniverse-app-debug`.
4. É um `.zip` — dentro dele está o `app-debug.apk`. Transfere esse arquivo pro celular
   (por cabo, WhatsApp pra você mesmo, Google Drive, etc.) e instala.
5. O Android provavelmente vai avisar "fonte desconhecida" — isso é normal pra apps fora da
   Play Store durante o desenvolvimento. Autoriza a instalação.

### Daí em diante
Toda vez que eu te mandar arquivos atualizados, repete só os passos 3 e 4 (copiar os
arquivos novos pra pasta, commit, push) — o passo 5 muda de lugar só o número da versão.

## Estrutura do projeto
```
omniverse-app/
├── www/              → o app em si (HTML/CSS/JS) — é aqui que a maior parte das mudanças acontece
│   ├── index.html
│   ├── css/app.css
│   └── js/
│       ├── app.js            → navegação entre abas
│       ├── storage.js        → salvar/carregar personagens no aparelho
│       ├── dados-sistema.js  → atributos, perícias e arquétipos do Sistema Omniverse
│       └── personagem.js     → lógica da criação de personagem
├── .github/workflows/build-apk.yml  → automação que compila o APK
├── capacitor.config.json
└── package.json
```
